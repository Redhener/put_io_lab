package put.io.testing.mocks;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Collections;
import java.util.List;
import java.util.stream.IntStream;

import org.junit.jupiter.api.Test;
import org.mockito.InOrder;

import put.io.students.fancylibrary.database.FancyDatabase;
import put.io.students.fancylibrary.database.IFancyDatabase;

public class ExpenseRepositoryTest {
    private ExpenseRepository expenseRepo;
    private List<Expense> expenses;

    @Test
    void loadExpenses() {
        IFancyDatabase mockDb = mock(IFancyDatabase.class);
        InOrder inOrder = inOrder(mockDb);
        when(mockDb.queryAll()).thenReturn(Collections.emptyList());
        expenseRepo = new ExpenseRepository(mockDb);
        expenseRepo.loadExpenses();
        inOrder.verify(mockDb).connect();
        inOrder.verify(mockDb).queryAll();
        inOrder.verify(mockDb).close();
        assertEquals(0, expenseRepo.getExpenses().size());
    }
    @Test
    void saveExpensesTest(){
        IFancyDatabase mockDb = mock(IFancyDatabase.class);
        InOrder inOrder = inOrder(mockDb);
        when(mockDb.queryAll()).thenReturn(Collections.emptyList());
        expenseRepo = new ExpenseRepository(mockDb);
        IntStream.range(0,5).forEach(i -> expenseRepo.addExpense(new Expense()));
        expenseRepo.saveExpenses();
        verify(mockDb,times(5)).persist(any(Expense.class));
        inOrder.verify(mockDb).connect();
        inOrder.verify(mockDb).close();
    }


}
